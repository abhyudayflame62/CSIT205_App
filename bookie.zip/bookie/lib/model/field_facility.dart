class FieldFacility {
  String name;
  String imageAsset;

  FieldFacility({required this.name, required this.imageAsset});
}
