import 'package:bookie/model/field_facility.dart';
import 'package:bookie/model/field_order.dart';
import 'package:bookie/model/sport_category.dart';
import 'package:bookie/model/sport_field.dart';
import 'package:bookie/model/user.dart';

var sampleUser = User(
    id: "user01",
    name: "Jash Popat",
    email: "jash.popat@flame.edu.in",
    accountType: "Student",
    imageProfile: "assets/images/Logo.png");

var _basketball = SportCategory(
  name: "Basketball",
  image: "assets/icons/basketball.png",
);
var _football = SportCategory(
  name: "Football",
  image: "assets/icons/soccer.png",
);
var _volley = SportCategory(
  name: "Volleyball",
  image: "assets/icons/volley.png",
);
var _tableTennis = SportCategory(
  name: "Table Tennis",
  image: "assets/icons/table_tennis.png",
);
var _tennis = SportCategory(
  name: "Tennis",
  image: "assets/icons/tennis.png",
);
var _gym = SportCategory(
  name: "Gym",
  image: "assets/icons/gym.png",
);

List<SportCategory> sportCategories = [
  _basketball,
  _tennis,
  _volley,
  _football,
  _gym,
  _tableTennis,
];

var _wifi = FieldFacility(name: "WiFi", imageAsset: "assets/icons/wifi.png");
var _toilet =
    FieldFacility(name: "Toilet", imageAsset: "assets/icons/toilet.png");
var _changingRoom = FieldFacility(
    name: "Changing Room", imageAsset: "assets/icons/changing_room.png");
var _canteen =
    FieldFacility(name: "Canteen", imageAsset: "assets/icons/canteen.png");
var _locker =
    FieldFacility(name: "Lockers", imageAsset: "assets/icons/lockers.png");
var _chargingArea = FieldFacility(
    name: "Charging Area", imageAsset: "assets/icons/charging.png");

SportField football = SportField(
  id: "01",
  name: "Arjuna Football Field",
  address: "Arjuna Sports Complex",
  category: _football,
  facilities: [_wifi, _toilet, _chargingArea, _changingRoom],
  phoneNumber: "Help Desk",
  openDay: "Monday to Sunday",
  openTime: "08.00",
  closeTime: "20.00",
  imageAsset: "assets/images/football.png",
  price: 150,
  author: "Abhyuday Singh",
  authorUrl: "https://github.com/abhyudayflame62/CSIT205_App",
  imageUrl: "Abhyuday's Android Phone",
);

SportField basketball = SportField(
    id: "02",
    name: "Arjuna Basketball Court",
    address: "Inside Arjuna Building",
    category: _basketball,
    facilities: [_wifi, _toilet, _changingRoom, _canteen],
    author: "Abhyuday Singh",
    authorUrl: "https://github.com/abhyudayflame62/CSIT205_App",
    imageUrl: "Abhyuday's Android Phone",
    phoneNumber: "Help Desk",
    openDay: "All Day",
    openTime: "07.00",
    closeTime: "22.00",
    imageAsset: "assets/images/basketball.png",
    price: 150);
SportField volleyball = SportField(
    id: "03",
    name: "Arjuna Volleyball Field",
    address: "Next to Swimming Pool, outside Arjuna Sports Complex",
    category: _volley,
    facilities: [_wifi, _toilet, _chargingArea, _changingRoom],
    author: "Abhyuday Singh",
    authorUrl: "https://github.com/abhyudayflame62/CSIT205_App",
    imageUrl: "Abhyuday's Android Phone",
    phoneNumber: "Help Desk",
    openDay: "All Day",
    openTime: "07.00",
    closeTime: "17.00",
    imageAsset: "assets/images/volleyball.png",
    price: 100);
SportField tableTennis = SportField(
    id: "04",
    name: "Arjuna Table Tennis Room",
    address: "1st Floor, Arjuna Sports Complex",
    category: _tableTennis,
    facilities: [_wifi, _toilet, _canteen],
    author: "Abhyuday Singh",
    authorUrl: "https://github.com/abhyudayflame62/CSIT205_App",
    imageUrl: "Abhyuday's Android Phone",
    phoneNumber: "Help Desk",
    openDay: "All Day",
    openTime: "09.00",
    closeTime: "23.00",
    imageAsset: "assets/images/tabletennis.png",
    price: 50);

SportField gym = SportField(
    id: "06",
    name: "Arjuna Gym",
    address: "Ground Floor, Behind Squash Court, Arjuna Sports Complex",
    category: _gym,
    facilities: [_wifi, _toilet, _chargingArea, _changingRoom],
    author: "Abhyuday Singh",
    authorUrl: "https://github.com/abhyudayflame62/CSIT205_App",
    imageUrl: "Abhuday's Android Phone",
    phoneNumber: "Help Desk",
    openDay: "All Day",
    openTime: "09.00",
    closeTime: "18.00",
    imageAsset: "assets/images/FLAME2.png",
    price: 150);

SportField tennis = SportField(
    id: "07",
    name: "Arjuna Tennis Court",
    address: "Next to Football Field, outside Arjuna Sports Complex",
    category: _tennis,
    facilities: [_wifi, _toilet, _locker],
    author: "Abhyuday Singh",
    authorUrl: "https://github.com/abhyudayflame62/CSIT205_App",
    imageUrl: "Abhyuday's Android Phone",
    phoneNumber: "Help Desk",
    openDay: "All Day",
    openTime: "08.00",
    closeTime: "17.00",
    imageAsset: "assets/images/tennis.png",
    price: 100);

List<SportField> sportFieldList = [
  football,
  basketball,
  volleyball,
  tableTennis,
  tennis,
  gym,
];

List<SportField> recommendedSportField = [
  basketball,
  tennis,
  volleyball,
  tableTennis,
  football,
  gym,
];

List<FieldOrder> dummyUserOrderList = [];

List<String> timeToBook = [
  "06.00",
  "07.00",
  "08.00",
  "09.00",
  "10.00",
  "11.00",
  "12.00",
  "13.00",
  "14.00",
  "15.00",
  "16.00",
  "17.00",
  "18.00",
  "19.00",
  "20.00",
  "21.00",
  "22.00",
  "23.00"
];
